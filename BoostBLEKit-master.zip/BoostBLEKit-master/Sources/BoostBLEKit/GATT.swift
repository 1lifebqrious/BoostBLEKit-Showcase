//
//  GATT.swift
//  BoostBLEKit
//
//  Created by Shinichiro Oba on 17/01/2018.
//  Copyright © 2018 bricklife.com. All rights reserved.
//

import Foundation

public struct GATT {
    
    public static let serviceUuid          = "00001623-1212-EFDE-1623-785FEABCD123"
    public static let characteristicUuid   = "00001624-1212-EFDE-1623-785FEABCD123"
}
